﻿using CarRental.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageBrands.xaml
    /// </summary>
    public partial class PageBrands : Page
    {
        public PageBrands()
        {
            InitializeComponent();
            LTVBrands.ItemsSource = CarRentalEntities.GetContext().Brands.ToList();
        }

        private void MenuAddBrand_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddBrands(null));
        }

        private void MenuEditBrand_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddBrands((Brands)LTVBrands.SelectedItem)); 
        }

        private void MenuSortV1_Click(object sender, RoutedEventArgs e)
        {
            LTVBrands.ItemsSource = CarRentalEntities.GetContext().Brands.OrderBy(x => x.TitleBrand).ToList();
        }

        private void MenuSortV2_Click(object sender, RoutedEventArgs e)
        {
            LTVBrands.ItemsSource = CarRentalEntities.GetContext().Brands.OrderByDescending(x => x.TitleBrand).ToList();
        }

        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            LTVBrands.ItemsSource = CarRentalEntities.GetContext().Brands.ToList();
        }

        private void MenuDelBrand_Click(object sender, RoutedEventArgs e)
        {
            var brandForRemoving = LTVBrands.SelectedItems.Cast<Brands>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {brandForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CarRentalEntities.GetContext().Brands.RemoveRange(brandForRemoving);
                    CarRentalEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    LTVBrands.ItemsSource = CarRentalEntities.GetContext().Brands.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchBrand_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LTVBrands.ItemsSource != null)
            {
                LTVBrands.ItemsSource = CarRentalEntities.GetContext().Brands.Where(x => x.TitleBrand.ToLower().Contains(SearchBrand.Text.ToLower())).ToList();
            }
            if (SearchBrand.Text.Count() == 0) LTVBrands.ItemsSource = CarRentalEntities.GetContext().Brands.ToList();
        }
    }
}
