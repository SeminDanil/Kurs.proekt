﻿using CarRental.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageClients.xaml
    /// </summary>
    public partial class PageClients : Page
    {
        public PageClients()
        {
            InitializeComponent();
            LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.ToList();
        }

        private void MenuAddClient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddClients(null));
        }

        private void MenuEditClient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddClients((Clients)LTVClients.SelectedItem));
        }

        private void MenuSortSurnameV1_Click(object sender, RoutedEventArgs e)
        {
            LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.OrderBy(x => x.Surname).ToList();
        }

        private void MenuSortSurnameV2_Click(object sender, RoutedEventArgs e)
        {
            LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.OrderByDescending(x => x.Surname).ToList();
        }

        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.ToList();
        }
        private void MenuFilterDiscount1_Click(object sender, RoutedEventArgs e)
        {
            LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.Where(x => x.Discount <= 10).ToList();
        }

        private void MenuFilterDiscount2_Click(object sender, RoutedEventArgs e)
        {
            LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.Where(x => x.Discount > 10).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.ToList();
        }

        private void MenuDelClient_Click(object sender, RoutedEventArgs e)
        {
            var clientForRemoving = LTVClients.SelectedItems.Cast<Clients>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {clientForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CarRentalEntities.GetContext().Clients.RemoveRange(clientForRemoving);
                    CarRentalEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchSurname_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LTVClients.ItemsSource != null)
            {
                LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.Where(x => x.Surname.ToLower().Contains(SearchSurname.Text.ToLower()) || x.Name.ToLower().Contains(SearchSurname.Text.ToLower()) || x.Patronymic.ToLower().Contains(SearchSurname.Text.ToLower())).ToList();
            }
            if (SearchSurname.Text.Count() == 0) LTVClients.ItemsSource = CarRentalEntities.GetContext().Clients.ToList();
        }
    }
}
