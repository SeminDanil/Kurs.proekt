﻿using CarRental.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddBrands.xaml
    /// </summary>
    public partial class PageAddBrands : Page
    {
        string imgLoc = "пусто";
        private Brands _currentBrands = new Brands();
        public PageAddBrands(Brands selectedBrand)
        {
            InitializeComponent();
            if (selectedBrand != null)
            {
                _currentBrands = selectedBrand;
                TitletxtBrand.Text = "Изменение бренда";
                BtnAddBrand.Content = "Изменить";
            }
            DataContext = _currentBrands;
        }

        private void BtnAddBrand_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentBrands.TitleBrand)) error.AppendLine("Укажите название");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentBrands.IDBrand == 0)
            {
                CarRentalEntities.GetContext().Brands.Add(_currentBrands);
                try
                {
                    CarRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageBrands());
                    MessageBox.Show("Новый бренд успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    if (imgLoc != "пусто" && imgLoc != "очистить")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        _currentBrands.LogoBrand = img;
                    }

                    if (imgLoc == "очистить") _currentBrands.LogoBrand = null;

                    CarRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageBrands());
                    MessageBox.Show("Член семьи успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelBrand_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageBrands());
        }

        private void LoadImage(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog
                {
                    Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*"
                };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    ImageBrand.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ClearImage(object sender, RoutedEventArgs e)
        {
            ImageBrand.Source = (ImageSource)ImageBrand.FindResource("UnknownBrand");
            imgLoc = "очистить";
        }
    }
}
