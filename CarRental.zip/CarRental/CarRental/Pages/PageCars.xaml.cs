﻿using CarRental.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageCars.xaml
    /// </summary>
    public partial class PageCars : Page
    {
        public PageCars()
        {
            InitializeComponent();
            LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.ToList();
        }

        private void MenuAddCar_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddCars(null));
        }

        private void MenuEditCar_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddCars((Cars)LTVCars.SelectedItem));
        }
    

        private void MenuSortV1_Click(object sender, RoutedEventArgs e)
        {
            LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.OrderBy(x => x.Brands.TitleBrand).ToList();
        }

        private void MenuSortV2_Click(object sender, RoutedEventArgs e)
        {
            LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.OrderByDescending(x => x.Brands.TitleBrand).ToList();
        }

        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.ToList();
        }

        private void MenuFilterPrice1_Click(object sender, RoutedEventArgs e)
        {
            LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.Where(x => x.Price <= 5000).ToList();
        }

        private void MenuFilterPrice2_Click(object sender, RoutedEventArgs e)
        {
            LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.Where(x => x.Price >= 5001).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.ToList();
        }

        private void MenuDelCar_Click(object sender, RoutedEventArgs e)
        {
            var carForRemoving = LTVCars.SelectedItems.Cast<Cars>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {carForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CarRentalEntities.GetContext().Cars.RemoveRange(carForRemoving);
                    CarRentalEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchCar_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LTVCars.ItemsSource != null)
            {
                LTVCars.ItemsSource = CarRentalEntities.GetContext().Brands.Where(x => x.TitleBrand.ToLower().Contains(SearchCar.Text.ToLower())).ToList();
            }
            if (SearchCar.Text.Count() == 0) LTVCars.ItemsSource = CarRentalEntities.GetContext().Cars.ToList();
        }
    }
}
