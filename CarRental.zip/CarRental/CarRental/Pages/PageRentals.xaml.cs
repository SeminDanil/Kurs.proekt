﻿using CarRental.Classes;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace CarRental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageRentals.xaml
    /// </summary>
    public partial class PageRentals : Page
    {
        public PageRentals()
        {
            InitializeComponent();
            LTVRentals.ItemsSource = CarRentalEntities.GetContext().Rentals.ToList();
        }

        private void MenuAddRental_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddRentals(null));
        }

        private void MenuEditRental_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddRentals((Rentals)LTVRentals.SelectedItem));
        }

        private void MenuExcelCRental_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Прокаты.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            int IndexRows = 1;
            ws.Cells[1][IndexRows] = "№";
            ws.Cells[2][IndexRows] = "Фамилия клиента";
            ws.Cells[3][IndexRows] = "Имя клиента";
            ws.Cells[4][IndexRows] = "Отчество клиента";
            ws.Cells[5][IndexRows] = "Модель автомобиля";
            ws.Cells[6][IndexRows] = "Дата получения";
            ws.Cells[7][IndexRows] = "Дата возврата";

            Excel.Range headerRange = ws.Range[ws.Cells[1][1], ws.Cells[7][1]];
            headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            headerRange.Font.Bold = true;
            headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            headerRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

            List<Rentals> printItems = new List<Rentals>();
            for (int i = 0; i < LTVRentals.Items.Count; i++) printItems.Add((Rentals)LTVRentals.Items[i]);
            foreach (var item in printItems)
            {
                ws.Cells[1][IndexRows + 1] = IndexRows;
                ws.Cells[2][IndexRows + 1] = item.Clients.Surname;
                ws.Cells[3][IndexRows + 1] = item.Clients.Name;
                ws.Cells[4][IndexRows + 1] = item.Clients.Patronymic;
                ws.Cells[5][IndexRows + 1] = item.Cars.Model;
                ws.Cells[6][IndexRows + 1] = item.DateOfReceipt;
                ws.Cells[7][IndexRows + 1] = item.DateReturn;
                IndexRows++;

                Excel.Range bodyRange = ws.Range[ws.Cells[1][IndexRows], ws.Cells[7][IndexRows]];
                bodyRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                bodyRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                bodyRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                Excel.Range numbersRange = ws.Range[ws.Cells[2, 1], ws.Cells[IndexRows, 1]];
                numbersRange.Font.Italic = true;
            }
            ws.Columns.AutoFit();
            ws.Rows.AutoFit();
            excelApp.Visible = true;
        }

        private void MenuDelRental_Click(object sender, RoutedEventArgs e)
        {
            var rentalForRemoving = LTVRentals.SelectedItems.Cast<Rentals>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rentalForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CarRentalEntities.GetContext().Rentals.RemoveRange(rentalForRemoving);
                    CarRentalEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    LTVRentals.ItemsSource = CarRentalEntities.GetContext().Rentals.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchClient_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LTVRentals.ItemsSource != null)
            {
                LTVRentals.ItemsSource = CarRentalEntities.GetContext().Clients.Where(x => x.Surname.ToLower().Contains(SearchClient.Text.ToLower()) || x.Name.ToLower().Contains(SearchClient.Text.ToLower()) || x.Patronymic.ToLower().Contains(SearchClient.Text.ToLower())).ToList();
            }
            if (SearchClient.Text.Count() == 0) LTVRentals.ItemsSource = CarRentalEntities.GetContext().Clients.ToList();
        }
    }
}
