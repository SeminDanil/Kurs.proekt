﻿using CarRental.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddCars.xaml
    /// </summary>
    public partial class PageAddCars : Page
    {
        string imgLoc = "пусто";
        private Cars _currentCars = new Cars();
        public PageAddCars(Cars selectedCar)
        {
            InitializeComponent();
            if (selectedCar != null)
            {
                _currentCars = selectedCar;
                TitletxtCar.Text = "Изменение автомобиля";
                BtnAddCar.Content = "Изменить";
            }
            DataContext = _currentCars;
            CmbBrand.ItemsSource = CarRentalEntities.GetContext().Brands.ToList();
            CmbBrand.SelectedValuePath = "IDBrand";
            CmbBrand.DisplayMemberPath = "TitleBrand";
            CmbGearbox.ItemsSource = CarRentalEntities.GetContext().GearBox.ToList();
            CmbGearbox.SelectedValuePath = "IDGearBox";
            CmbGearbox.DisplayMemberPath = "Title";
        }

        private void BtnAddCar_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentCars.IDBrand))) error.AppendLine("Укажите бренд");
            if (string.IsNullOrWhiteSpace(_currentCars.Model)) error.AppendLine("Укажите модель");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentCars.YearOfCarManufacture))) error.AppendLine("Укажите год выпуска");
            if (string.IsNullOrWhiteSpace(_currentCars.BodyType)) error.AppendLine("Укажите тип кузова");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentCars.IDGearBox))) error.AppendLine("Укажите коробку передач");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentCars.Price))) error.AppendLine("Укажите стоимость в сутки");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentCars.IDCar == 0)
            {
                CarRentalEntities.GetContext().Cars.Add(_currentCars);
                try
                {
                    CarRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCars());
                    MessageBox.Show("Новый автомобиль успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    if (imgLoc != "пусто" && imgLoc != "очистить")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        _currentCars.ImageCar = img;
                    }

                    if (imgLoc == "очистить") _currentCars.ImageCar = null;

                    CarRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCars());
                    MessageBox.Show("Автомобиль успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelCar_Click(object sender, RoutedEventArgs e)
        {

            Classes.ClassFrame.frmObj.Navigate(new PageCars());
        }

        private void LoadImage(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog
                {
                    Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*"
                };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    ImageCar.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ClearImage(object sender, RoutedEventArgs e)
        {
            ImageCar.Source = (ImageSource)ImageCar.FindResource("UnknownCar");
            imgLoc = "очистить";
        }
    }
}
