﻿using CarRental.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRental.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddRentals.xaml
    /// </summary>
    public partial class PageAddRentals : Page
    {
        private Rentals _currentRentals = new Rentals();
        public PageAddRentals(Rentals selectedRental)
        {
            InitializeComponent();
            if (selectedRental != null)
            {
                _currentRentals = selectedRental;
                TitletxtRental.Text = "Изменение проката";
                BtnAddRental.Content = "Изменить";
            }
            DataContext = _currentRentals;
            CmbClient.ItemsSource = CarRentalEntities.GetContext().Clients.ToList();
            CmbClient.SelectedValuePath = "IDClient";
            CmbClient.DisplayMemberPath = "Surname";
            CmbCar.ItemsSource = CarRentalEntities.GetContext().Cars.ToList();
            CmbCar.SelectedValuePath = "IDCar";
            CmbCar.DisplayMemberPath = "Model";

        }

        private void BtnAddRental_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentRentals.IDClient))) error.AppendLine("Укажите фамилию клиента");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentRentals.IDCar))) error.AppendLine("Укажите модель автомобиля");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentRentals.DateOfReceipt))) error.AppendLine("Укажите дату получения");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentRentals.DateReturn))) error.AppendLine("Укажите дату возврата");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentRentals.IDRental == 0)
            {
                CarRentalEntities.GetContext().Rentals.Add(_currentRentals);
                try
                {
                    CarRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageRentals());
                    MessageBox.Show("Новый прокат успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    CarRentalEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageRentals());
                    MessageBox.Show("Прокат успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelRental_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageRentals());
        }
    }
}
